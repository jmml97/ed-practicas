/**
 * @file tablero.h
 * @brief Fichero de cabecera para el TDA Tablero
 *
 */

#ifndef __TABLERO_H__
#define __TABLERO_H__

#include <iosfwd>
#include <vector>
#include <string>

using namespace std;

/******************************************************************************/
/**
 * @brief T.D.A. Tablero.
 *
 * Diremos que un tablero está vacío cuando la última columna donde se insertó
 * una ficha valga -1.
 */
class Tablero
{
  private:
    vector<vector<int> > tablero;  ///< Matriz que representa un estado del juego.
    const int filas;               ///< Número de filas que tiene el tablero.
    const int columnas;            ///< Número de columnas que tiene el tablero.
    int turno;                     ///< Indica a qué jugador le toca poner ficha. 1 para el jugador 1, 2 para el jugador 2.
    int ult_col;                   ///< Columna donde se insertó la última ficha

    /**
     * @brief Crea el tablero de tamaño filas/columnas
     */
    void reserve();

public:
    /// Representa el número de fichas necesarias para ganar
    const static int N_FICHAS_GANAR = 4;
    /// Carácter que representa una ficha del Jugador 1
    const static char CHAR_J1 = 'x';
    /// Carácter que representa una ficha del Jugador 2
    const static char CHAR_J2 = 'o';
    /// Color de la ficha del Jugador 1 (ANSI escape code)
    const static string COLOR_J1;
    /// Color de la ficha del Jugador 2 (ANSI escape code)
    const static string COLOR_J2;

    /**
     * @brief Constructor por defecto. Crea un tablero de tamaño predefinido.
     */
    Tablero();

    /**
     * @brief Constructor. Crea un tablero introduciendo el tamaño del mismo.
     *        El estado inicial del tablero es todo 0, es decir, todo el tablero
     *        está libre. El turno inicial es el del jugador 1.
     * @param filas : Número de filas que tendrá el tablero.
     * @param columnas : Nümero de columnas del tablero.
     */
    Tablero(const int filas, const int columnas);

    /**
     * @brief Constructor de copia. Crea un tablero a partir de otro dado.
     * @param t : Tablero origen que se va a copiar.
     */
    Tablero(const Tablero& t);


    /**
     * @brief Destructor.
     */
    ~Tablero() { }

    /**
     * @brief Comprueba si hay hueco en una columna 'pos'.
     * @param pos : Columna sobre la que se va a comprobar si hay hueco para introducir
     *              una ficha.
     * @return Devuelve la fila en la que hay hueco (en esa columna).
     *         Si no hay hueco devuelve -1.
     */
    int hayHueco(int pos);

    /**
     * @brief Comprueba si el tablero está lleno.
     * @return Devuelve true si el tablero está lleno, y false en otro caso.
     */
    bool estaLleno();

    /**
     * @brief Comprueba si un tablero constante está vacío.
     * @return true si está vacío, false si no.
     */
    bool estaVacio() const { return ult_col == -1; }

    /**
     * @brief Comprueba si un tablero está vacío
     * @return true si está vacío, false si no.
     */
    bool estaVacio() { return ult_col == -1; }

    /**
     * @brief Coloca una ficha en la columna especificada del jugador correspondiente.
     *        Si le toca al jugador 1, inserta la ficha en esa posición. (Si hay hueco)
     * @param pos : Columna en la que se va a intentar colocar la ficha.
     * @return Devuelve true si se ha introducido la ficha en la posición.
     *         False en otro caso.
     */
    bool colocarFicha(int pos);

    /**
     * @brief Cambia el turno del jugador que toca.
     * @return Devuelve el turno que toca.
     */
    int cambiarTurno();

    /**
     * @brief Devuelve la anchura del tablero.
     * @return Número de columnas del tablero (anchura).
     */
    const int GetColumnas() const { return columnas; }

    /**
     * @brief Devuelve la altura del tablero.
     * @return Número de filas del tablero (altura).
     */
    const int GetFilas() const { return filas; }

    /**
     * @brief Devuelve la columna donde se insertó la última ficha.
     */
    int GetUltCol() const { return ult_col; }

    /**
     * @brief Función que devuelve el atributo tablero.
     * @return Devuelve un vector de vectores de enteros (una matriz) de enteros
     *         representando un tablero.
     */
    vector<vector<int> > GetTablero() const { return tablero; }

    /**
     * @brief Devuelve el elemento en la posición (i,j) del tablero.
     * @pre 0 <= i < filas; 0 <= j < columnas
     */
    int GetElemento(int i, int j) const { return tablero[i][j]; }

    /**
     * @brief Asigna un tablero introducido como parámetro.
     * @param tablero : Matriz (vector de vectores de enteros) representante de
     *        un estado del juego.
     */
    void SetTablero(vector<vector<int> > tablero, int ult_col, int turno);

    /**
     * @brief Turno del estado actual.
     * @return Devuelve el turno del jugador. {1, 2}
     */
    int GetTurno() { return turno; }

    /**
     * @brief Operador de igualdad. Asigna los valores del tablero de la derecha
     *        al de la izquierda.
     * @param derecha : Tablero origen que se va a copiar.
     * @return Devuelve la referencia al tablero destino que se ha copiado.
     */
    Tablero& operator=(const Tablero& derecha);

    /**
     * @brief Operador flujo de salida. Imprime el tablero por el flujo de salida.
     * @param os : Flujo de salida.
     * @param t : Tablero que se va a imprimir.
     */
    friend ostream& operator<<(ostream& os, const Tablero& t);

    /**
     * @brief Función que calcula en un estado concreto del tablero, quién gana.
     *        En cualquier estado del tablero, se puede decidir por el estado del
     *        juego: gana el jugador 1, empate o gana el jugador 2.
     * @return Devuelve {0, 1, 2} 0 si no ha ganado nadie. 1 si ha ganado el
     *         jugador 1 y 2 si ha ganado el jugador 2.
     */
    int quienGana();
};

/**
 * @brief Imprime un conjunto de tipo T sobre el flujo de salida.
 * @param s: Flujo de salida.
 * @param c: Conjunto con los elementos a imprimir.
 * @return Devuelve el flujo de salida.
 **/
template <class T>
ostream& operator<<(ostream& s, const vector<T>& c);

/**
 * @brief Imprime una matriz de tipo T sobre el flujo de salida.
 * @param s: Flujo de salida.
 * @param c: Vector de vectores (matriz) de tipo T a imprimir.
 * @return Devuelve el flujo de salida.
 */
template <class T>
ostream& operator<<(ostream& s, const vector<vector<T> >& c);

#endif

/* Fin fichero: tablero.h */
